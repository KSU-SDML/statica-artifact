﻿// Copyright (c) Files Community
// Licensed under the MIT License.

namespace Files.App.Actions
{
	[GeneratedRichCommand]
	internal sealed partial class OpenInNewWindowAction : BaseOpenInNewWindowAction
	{
	}
}
