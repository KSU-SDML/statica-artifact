﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

using System.Diagnostics.CodeAnalysis;
using System.Text;
using Microsoft.Extensions.Logging;

namespace Garnet.common.Parsing
{
    /// <summary>
    /// Exception wrapper for RESP parsing errors.
    /// </summary>
    public class RespParsingException : GarnetException
    {
        /// <summary>
        /// Construct a new RESP parsing exception with the given message.
        /// </summary>
        /// <param name="message">Message that described the exception that has occurred.</param>
        /// <param name="logLevel">Logging level for the exception that occurred</param>
        RespParsingException(string message, LogLevel logLevel = LogLevel.Critical) : base(message, logLevel)
        {
            // Nothing...
        }

        /// <summary>
        /// Throw an "Unexcepted Token" exception.
        /// </summary>
        /// <param name="token">The character that was unexpected.</param>
        [DoesNotReturn]
        public static void ThrowUnexpectedToken(byte token)
        {
            var c = (char)token;
            var escaped = char.IsControl(c) ? $"\\x{token:x2}" : c.ToString();
            Throw($"Unexpected character '{escaped}'.");
        }

        /// <summary>
        /// Throw an invalid string length exception.
        /// </summary>
        /// <param name="len">The invalid string length.</param>
        [DoesNotReturn]
        public static void ThrowInvalidStringLength(long len)
        {
            Throw($"Invalid string length '{len}'.");
        }

        /// <summary>
        /// Throw an invalid length exception.
        /// </summary>
        /// <param name="len">The invalid length.</param>
        [DoesNotReturn]
        public static void ThrowInvalidLength(long len)
        {
            Throw($"Invalid length '{len}'.");
        }

        /// <summary>
        /// Throw NaN (not a number) exception.
        /// </summary>
        /// <param name="buffer">Pointer to an ASCII-encoded byte buffer containing the string that could not be converted.</param>
        /// <param name="length">Length of the buffer.</param>
        [DoesNotReturn]
        public static unsafe void ThrowNotANumber(byte* buffer, int length)
        {
            Throw($"Unable to parse number: {Encoding.ASCII.GetString(buffer, length)}");
        }

        /// <summary>
        /// Throw a exception indicating that an integer overflow has occurred.
        /// </summary>
        /// <param name="buffer">Pointer to an ASCII-encoded byte buffer containing the string that caused the overflow.</param>
        /// <param name="length">Length of the buffer.</param>
        [DoesNotReturn]
        public static unsafe void ThrowIntegerOverflow(byte* buffer, int length)
        {
            Throw($"Unable to parse integer. The given number is larger than allowed: {Encoding.ASCII.GetString(buffer, length)}");
        }

        /// <summary>
        /// Throw helper that throws a RespParsingException.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="logLevel">LogLevel for exception.</param>
        [DoesNotReturn]
        public static new void Throw(string message, LogLevel logLevel = LogLevel.Critical) =>
            throw new RespParsingException(message, logLevel);
    }
}